$(document).ready(function(){

    $('.mobile-menu').on('click', function(){
        $('#menu').addClass('menu_open');
    });
    $('.menu__close > span').on('click', function () {
        $('#menu').removeClass('menu_open');
    });
    /// YA Maps 
    ymaps.ready(init);
    function init() {
        // Создание карты.    
        var myMap = new ymaps.Map("map", {
            center: [51.533103, 46.034158],
            zoom: 12,
            controls: []
        });
        myMap.behaviors.disable('scrollZoom'); 
        myMap.geoObjects
            .add(new ymaps.Placemark([51.533103, 46.034158], {
                balloonContent: '<strong>Евротрак</strong>'
            }, {
                preset: 'islands#dotIcon',
                iconColor: '#735184'
            }));
    }
    
});